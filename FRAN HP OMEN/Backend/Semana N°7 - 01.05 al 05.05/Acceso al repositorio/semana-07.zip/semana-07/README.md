# Desarrollo de Software - Semana 7

## Contenido de la semana

Esta semana de clase continuaremos trabajando con Express, concentrándonos en el manejo de rutas, errores y conexión entre aplicaciones.

## Lista de materiales

- [Apunte 14 - Express - Router](./apunte-14/Apunte14.md)
- [Apunte 15 - Express - Middleware](./apunte-15/Apunte15.md)

## Clonar el presente repositorio

``` bash
cd dds_work_dir
git clone https://labsys.frc.utn.edu.ar/gitlab/desarrollo-de-software1/materiales/semana-07.git
```

## Autores

Soledad Romero, Felipe Steffolani - Cátedra de Desarrollo de Software

## License

Este trabajo está licenciado bajo una Licencia Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional. Para ver una copia de esta licencia, visita [https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es](!https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es).
