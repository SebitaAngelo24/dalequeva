let tareas = [];
let contador = 0;

// Constructor 
function Tarea(nombre){
    this.id = ++contador;
    this.nombre = nombre;
    this.realizada = false;
}

const agregarTarea = function(nombre){
    // Crear un objeto: 1
    // const nuevaTarea = {
    //     id: ++contador, 
    //     nombre: nombre,
    //     realizada: false
    // };

    // Crear un objeto: 2
    // const nuevaTarea = new Object(); 
    // nuevaTarea.id = ++contador;
    // nuevaTarea.nombre = nombre;
    // nuevaTarea.realizada = false;

    // Agregar tarea sin constructor
    // tareas.push(nuevaTarea);

    
    // Agregar tarea usando el constructor
    // Crear un objeto: 3
    tareas.push(new Tarea(txtNombreTarea.value));
    // console.table(tareas);
    renderListaTareas();
}

const removerTarea = function(index){
    tareas.splice(index,1);
    renderListaTareas();
}

function renderListaTareas(){
    const listaTareas = document.getElementById('listaTareas');
    if (listaTareas){
        let contenido = '';

        for (let i=0; i< tareas.length; i++){
            contenido += `
            <li class="list-group-item">
                <input class="form-check-input me-1" type="checkbox" value="" id="firstCheckbox">
                <label class="form-check-label" for="firstCheckbox">${tareas[i].nombre}</label>
                <i class="bi bi-trash text-danger float-end" onclick=removerTarea(${i})></i>
            </li>            
            `
        }


        listaTareas.innerHTML = contenido;
    }

}

// const btnAgregarTarea = document.getElementById('btnAgregarTarea');
const btnAgregarTarea = document.querySelector('#btnAgregarTarea');
// const btnAgregarTarea = document.querySelectorAll('#btnAgregarTarea');
const txtNombreTarea = document.getElementById('txtNombreTarea');


// function onAgregarTarea1() {
//     console.log('Presionó el botón')    
// } 

// const onAgregarTarea2 =  function () {
//     console.log('Presionó el botón')    
// }

// const onAgregarTarea3 = nombre => console.log('Desde fn flecha' + nombre)
// onAgregarTarea3('Jose');


if (btnAgregarTarea && txtNombreTarea){
    btnAgregarTarea.addEventListener('click', ()=>{
        if (txtNombreTarea.value){
            agregarTarea(txtNombreTarea.value)
            txtNombreTarea.value = '';
        }
    });
}
