# Ejercicio Paso a Paso: AMB de usuarios con Sqlite.

## Parte 1

### Paso 1: Preparación del proyecto

En este paso inicializamos el proyecto e instalamos la librería `sqlite3` que usaremos para conectarnos a la base de datos

```sh
mkdir abm_usuarios
cd abm_usuarios
npm init -y
npm i sqlite3
touch app.js
```

### Paso 2: Importar el paquete `sqlite3` y conectarnos a la base de datos

Podemos importar el paquete `sqlite3` como módulo CommonJS (CJS) o como módulo ES (ESM). Veremos ambas alternativas pero nos quedamos con la segunda porque luego vamos a usar otro paquete cuya versión más actual solo admite esta alternativa.
Si querés aprender un poco más sobre la distinción entre CJS y ESM podés ver éste artículo: [CommonJS vs ES Modules](https://lenguajejs.com/automatizadores/introduccion/commonjs-vs-es-modules/) u otros similares. 

Como módulo CommonJS nuestro archivo `app.js` quedaría:


```javascript
const sqlite3 = require('sqlite3').verbose();
```

En el caso de importarlo cómo módulo ESM tendríamos:

```javascript
import * as sqlite3 from 'sqlite3';
```

Además, este segundo caso necesitamos modificar el archivo `package.json` y agregar está clave:

```json
  "type":"module",
```

Ahora vamos a conectarnos a la base de datos. En algunos casos, por ejemplo para testear, podemos preferir utilizar una base de datos 'en memoria' (sin persistencia en disco). En este caso la conexión sería asi: 

```javascript 
import * as sqlite3 from 'sqlite3';

const db = new sqlite3.Database(':memory:');
```

Si, en cambio, queremos que nuestra base de datos persista en disco, y eso es lo que necesitamos ahora, vamos a especificarlo de esta manera. El archivo de la base de datos en este caso: `usuarios.db` estará en la misma carpeta de nuestro proyecto.

```javascript 
import * as sqlite3 from 'sqlite3';

const db = new sqlite3.default.Database("./usuarios.db",sqlite3.OPEN_READWRITE, (err)=>{
  if (err) return console.error(err.message);
})
```

Si lo ejecutamos por primera vez:
```sh
node app.js
```
vamos a observar que el archivo usuarios.db ha sido creado.

### Paso 3: Crear la tabla `usuarios`

Ahora vamos crear una tabla para almacenar los usuarios. Vamos a crearla con los siguientes campos (podés incluir las variaciones que se te ocurran):
- id
- nombre
- apellido
- usuario
- password 
- email

Para crear la tabla vamos a usar la sentencia SQL `CREATE TABLE`. Asignamos la query SQL a una variable y la ejecutamos con el método `run()` 

```javascript 
import * as sqlite3 from 'sqlite3';

const db = new sqlite3.default.Database("./usuarios.db",sqlite3.OPEN_READWRITE, (err)=>{
  if (err) return console.error(err.message);
})

const sql = "CREATE TABLE usuarios (id INTEGER PRIMARY KEY, nombre, apellido, usuario, password, email)";
db.run(sql);
```

Para evitar crear la tabla cada vez que ejectutamos la app, y el consiguiente error porque la tabla ya existe, podemos usar `IF NOT EXISTS`. Asi: 


```javascript 
import * as sqlite3 from 'sqlite3';

const db = new sqlite3.default.Database("./usuarios.db",sqlite3.OPEN_READWRITE, (err)=>{
  if (err) return console.error(err.message);
})

const sql = "CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY, nombre, apellido, usuario, password, email)";
db.run(sql);
```
Cuando ejecutemos la aplicación se creará la tabla (si no existe). Podemos verificar esto usando un cliente para sqlite como [DBeaver](https://dbeaver.io/) o más sencillo y liviano [sqlite3 cli](https://sqlite.org/cli.html) que es probable que ya tengas instalado en tu sistema operativo.

### Paso 4: Insertar filas

En este punto ya podemos inspeccionar el contenido de la tabla ... pero la tabla está vacía. Entonces vamos a comenzar creando alguna o algunas filas en la tabla usando la sentencia SQL: `insert`

```javascript 
import * as sqlite3 from 'sqlite3';

const db = new sqlite3.default.Database("./usuarios.db",sqlite3.OPEN_READWRITE, (err)=>{
  if (err) return console.error(err.message);
})

const sql = "CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY, nombre, apellido, usuario, password, email)";
db.run(sql);

const sql_insert = "INSERT INTO usuarios (nombre, apellido, usuario, password, email) VALUES (?,?,?,?,?)";
const params = ['Juan', 'Perez', 'jperez', 'secreto', 'jperez@example.com'];
db.run (sql_insert, params, (err) => {
  if (err) return console.error(err.message)
})
```

Cada vez que ejecutemos nuestra aplicación se insertará una fila con los mismos datos, de modo que podemos variar algunos de ellos de modo de tener filas distintas. Más adelante vamos a agregar un poco de interactividad a nuestra pequeña aplicación, pero por ahora podemos hacerlo de esta forma rudimentaria.

### Paso 5: Listar el contenido de la tabla

Ahora con algunos usuarios en nuestra tabla de usuarios vamos a listar todas las filas de la tabla: 
Podés comentar o eliminar las líneas de código que insertan usuarios de modo de no terminar con tantas filas iguales.

```javascript
import * as sqlite3 from 'sqlite3';

const db = new sqlite3.default.Database("./usuarios.db",sqlite3.OPEN_READWRITE, (err)=>{
  if (err) return console.error(err.message);
})

const sql = "CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY, nombre, apellido, usuario, password, email)";
db.run(sql);

const sql_select = "SELECT * FROM usuarios"
db.all(sql_select, [], (err,rows)=>{
  if(err) return console.error(err.message);
  rows.forEach((row)=>{
    console.log(row);
  });
});
```

### Paso 6: Modificar una fila

Ahora vamos a implementar la operación de modificación de una fila de la tabla usuarios. En este caso vamos a modificar el valor de `usuario` en la fila cuyo `id` es 2.

```javascript
import * as sqlite3 from 'sqlite3';

const db = new sqlite3.default.Database("./usuarios.db",sqlite3.OPEN_READWRITE, (err)=>{
  if (err) return console.error(err.message);
})

const sql = "CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY, nombre, apellido, usuario, password, email)";
db.run(sql);

const sql_update = "UPDATE usuarios SET usuario = ? WHERE id = ?";
const params = ['jperez_modificado', 2];
db.run (sql_update, params, (err) => {
  if (err) return console.error(err.message);
})

const sql_select = "SELECT * FROM usuarios"
db.all(sql_select, [], (err,rows)=>{
  if(err) return console.error(err.message);
  rows.forEach((row)=>{
    console.log(row);
  });
});
```

### Paso 7: Eliminar una fila

Por último para completar las cuatro operaciones, vamos a ver como remover o eliminar una fila. Haremos esto con la fila que acabamos de modificar, la que tiene `id` 2.

```javascript
import * as sqlite3 from 'sqlite3';

const db = new sqlite3.default.Database("./usuarios.db",sqlite3.OPEN_READWRITE, (err)=>{
  if (err) return console.error(err.message);
})

const sql = "CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY, nombre, apellido, usuario, password, email)";
db.run(sql);

const sql_delete = "DELETE FROM usuarios WHERE id = ?";
const params = [2];
db.run (sql_delete, params, (err) => {
  if (err) return console.error(err.message);
})

const sql_select = "SELECT * FROM usuarios"
db.all(sql_select, [], (err,rows)=>{
  if(err) return console.error(err.message);
  rows.forEach((row)=>{
    console.log(row);
  });
});

```

## Parte 2

En este punto ya vimos todo lo que necesitamos para tener las nociones baśicas de las operaciones de crear, leer, actualizar y eliminar con `sqlite` por lo tanto podés dejar el tutorial aquí si querés.

En esta segunda parte solo le vamos a agregar interactividad a nuestra aplicación usando un paquete que se llama [`inquirer`](https://www.npmjs.com/package/inquirer) y que nos permitirá realizar estas operaciones de forma interactiva de modo de que la aplicación sea más amigable, más útil y que eventualmente nos sirva de base para otras aplicaciones. 

`inquirer` es un paquete que nos permite construir interfaces de usuario de línea de comandos interactivas muy facilmente. Si alguna vez intentaste construir este tipo de interfaces a mano o usando bibliotecas como `ncurses` vas a ver que es realemente facil.

Te invitamos a darle una mirada rápida a la documentación de [`inquirer`](https://www.npmjs.com/package/inquirer) ya que de esta forma te vas a dar una idea de qué es lo que se puede hacer y cómo (método `prompt()`) se puede hacer y los resultados que se logran.

### Paso 8: Construir el menú.

En este paso vamos a olvidarnos por un momento de la base de datos, `sqlite` y lo que hicimos hasta ahora, porque cómo dijimos vamos a concentrarnos en la interactividad.

Podemos comentar o eliminar o pasar a otro archivo el código que escribimos hasta el momento y vamos a construir un menú desde el cual vamos a invocar cada una de las operaciones que implementamos previamente.

Antes que nada vamos a instalar el paquete `inquirer`

```sh
npm i inquirer
```

Y lo importamos en el archivo `app.js`

```javascript
import inquirer from 'inquirer';
```

Para construir nuestro menú vamos a usar un prompt de tipo: `list` con las opciones: Listar, Agregar, Modificar, Eliminar 

Nuestra `app.js` queda así: 

```javascript
import * as sqlite3 from 'sqlite3';
import inquirer from 'inquirer';

const preguntas = [
  {
    type: 'list',
    name: 'accion',
    message: 'Elegí una opción: ',
    choices: ['Listar', 'Agregar', 'Modificar', 'Eliminar']
  }  
];

const main = () => {
  console.clear();

  inquirer.prompt(preguntas).then(
    (respuesta) => {
      console.log(respuesta.accion);
    }
  );

}

main();
```

Si la ejecutás verás el menú. Probá distintas acciones.

### Paso 9: Invocar funciones para las distintas acciones.

Ahora vamos a agregar una instrucción `switch` que nos permita invocar el código que construimos anteriormente pero con dos cambios importantes:

- cada una de las operaciones estará en una función 
- cada operación será interactiva y aceptará input del usuario usando también `inquirer.prompt()` (implementaremos esto en el próximo paso)

```javascript
import * as sqlite3 from 'sqlite3';
import inquirer from 'inquirer';

const preguntas = [
  {
    type: 'list',
    name: 'accion',
    message: 'Elegí una opción: ',
    choices: ['Listar', 'Agregar', 'Modificar', 'Eliminar']
  }  
];

const listarUsuarios = () => {
  console.log("Listar Usuarios")
}

const agregarUsuario = () => {
  console.log("Agregar Usuario")
}

const modificarUsuario = () => {
  console.log("Modificar Usuario")
}

const eliminarUsuario = () => {
  console.log("Eliminar Usuario")
}

const main = () => {
  console.clear();

  inquirer.prompt(preguntas).then(
    (respuesta) => {

      switch(respuesta.accion){
        case 'Listar':
          listarUsuarios();
          break;
        case 'Agregar':
          agregarUsuario();
          break;
        case 'Modificar':
          modificarUsuario();
          break;
        case 'Eliminar':
          eliminarUsuario();
          break;
      }
    
    }
  );

}

main();
```

## Paso 10: Implementar las operaciones interactivas

Ahora vamos a implementar cada una de las operaciones pero permitiendo que el usuario ingrese los parámetros en los casos en que éstas lo requieran. También usaremos `inquirer` para pedirle los datos al usuario.

```javascript
import * as sqlite3 from 'sqlite3';
import inquirer from 'inquirer';

const preguntas = [
  {
    type: 'list',
    name: 'accion',
    message: 'Elegí una opción: ',
    choices: ['Listar', 'Agregar', 'Modificar', 'Eliminar']
  }  
];

const inicializarDb = () => {
  const db = new sqlite3.default.Database("./usuarios.db",sqlite3.OPEN_READWRITE, (err)=>{
    if (err) return console.error(err.message);
  })

  const sql = "CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY, nombre, apellido, usuario, password, email)";
  db.run(sql);

  return db;
}

const listarUsuarios = (db) => {
  const sql = "SELECT * FROM usuarios"
  db.all(sql, [], (err,rows)=>{
    if(err) return console.error(err.message);
    rows.forEach((row)=>{
      console.log(row);
    });
  });
}

const agregarUsuario = (db) => {
  inquirer.prompt([
    {type: 'input', name: 'nombre', message: 'Nombre:'},
    {type: 'input', name: 'apellido', message: 'Apellido:'},
    {type: 'input', name: 'usuario', message: 'Usuario:'},
    {type: 'password', name: 'password', message: 'Password:'},
    {type: 'input', name: 'email', message: 'Email:'}
  ]).then(answers => {
    const sql = "INSERT INTO usuarios (nombre, apellido, usuario, password, email) VALUES (?,?,?,?,?)";
    const params = [answers.nombre, answers.apellido, answers.usuario, answers.password, answers.email];
    db.run (sql,params, (err) => {
      if (err) return console.error(err.message)
    })
  }) 
}

const modificarUsuario = (db) => {
  inquirer.prompt ([
    {type: 'number', name: 'id', message: 'Id Usuario:'},
    {type: 'input', name: 'usuario', message: 'Usuario:'}
  ]).then(answers => {
    const sql = "UPDATE usuarios SET usuario = ? WHERE id = ?";
    const params = [answers.usuario, answers.id];
    db.run (sql, params, (err) => {
      if (err) return console.error(err.message);
    })
  })
}

const eliminarUsuario = (db) => {
  inquirer.prompt ([
    {type: 'number', name: 'id', message: 'Id Usuario:'}
  ]).then(answers => {
    const sql = "DELETE FROM usuarios WHERE id = ?";
    const params = [answers.id];
    db.run (sql, params, (err) => {
      if (err) return console.error(err.message);
    })
  })
}

const main = () => {
  const db = inicializarDb();
  console.clear();

  inquirer.prompt(preguntas).then(
    (respuesta) => {

      switch(respuesta.accion){
        case 'Listar':
          listarUsuarios(db);
          break;
        case 'Agregar':
          agregarUsuario(db);
          break;
        case 'Modificar':
          modificarUsuario(db);
          break;
        case 'Eliminar':
          eliminarUsuario(db);
          break;
      }
    
    }
  );

}

main();
```
