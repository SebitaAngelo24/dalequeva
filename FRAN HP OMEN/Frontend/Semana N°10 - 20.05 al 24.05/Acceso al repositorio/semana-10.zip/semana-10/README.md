# Desarrollo de Software - Semana 10

## Contenido de la semana

- Introducción a React

## Lista de materiales

- [Apunte 19](./apunte-19/Apunte19.md)
React, Requerimientos, Crear una aplicación con React. Utilización comando npx, Estructura de una aplicación. Componentes funcionales y de clase. Renderización de componentes. Sintaxis JSX. Formas de aplicar estilos a elementos en un componente en React con className y style.
- [Apunte 20](apunte-20/Apunte20.md)
 React, Renderizado de múltiples elementos en un Componente - Etiqueta Fragment. Que son los hooks. Hook useState. Hook useEffect, servicios mock.

## Clonar el presente repositorio

``` bash
cd dds_work_dir
git clone https://labsys.frc.utn.edu.ar/gitlab/desarrollo-de-software1/materiales/semana-10.git
```

## Lista de Ejemplos

- [Hola Mundo React](./ejercitacion/holamundo_react/)
- [Ejemplo básico con React](./ejercitacion/ejemplo-app/)

## Autores

Jorge Harach - Cátedra de Desarrollo de Software

## License

Este trabajo está licenciado bajo una Licencia Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional. Para ver una copia de esta licencia, visita [https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es](!https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es).
