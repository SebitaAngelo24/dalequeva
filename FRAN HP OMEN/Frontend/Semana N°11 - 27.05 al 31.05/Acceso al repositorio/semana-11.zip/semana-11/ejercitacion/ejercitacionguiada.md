# Enunciado ejercitación Ruteo con React

Dada la siguiente colección de objetos:

```javascript
[
  { id: 1, descripcion: 'Televisor LG', categoria: 'Electrodomésticos', precio: 599.99 },
  { id: 2, descripcion: 'Lavadora Samsung', categoria: 'Línea blanca', precio: 399.99 },
  { id: 3, descripcion: 'Frigorífico Bosch', categoria: 'Electrodomésticos', precio: 899.99 },
  { id: 4, descripcion: 'Robot de cocina Moulinex', categoria: 'Electrodomésticos', precio: 199.99 },
  { id: 5, descripcion: 'Cafetera Nespresso', categoria: 'Electrodomésticos', precio: 99.99 },
  { id: 6, descripcion: 'Batidora Philips', categoria: 'Electrodomésticos', precio: 49.99 },
  { id: 7, descripcion: 'Horno Teka', categoria: 'Electrodomésticos', precio: 599.99 },
  { id: 8, descripcion: 'Aspiradora Dyson', categoria: 'Electrodomésticos', precio: 349.99 },
  { id: 9, descripcion: 'Plancha de vapor Rowenta', categoria: 'Electrodomésticos', precio: 69.99 },
  { id: 10, descripcion: 'Aire acondicionado LG', categoria: 'Electrodomésticos', precio: 899.99 },
  { id: 11, descripcion: 'Secadora Siemens', categoria: 'Línea blanca', precio: 499.99 },
  { id: 12, descripcion: 'Máquina de hielo Klarstein', categoria: 'Electrodomésticos', precio: 179.99 },
  { id: 13, descripcion: 'Microondas Panasonic', categoria: 'Electrodomésticos', precio: 129.99 },
  { id: 14, descripcion: 'Lavavajillas Whirlpool', categoria: 'Línea blanca', precio: 599.99 },
  { id: 15, descripcion: 'Placa de inducción Balay', categoria: 'Electrodomésticos', precio: 349.99 },
  { id: 16, descripcion: 'Exprimidor Taurus', categoria: 'Electrodomésticos', precio: 24.99 },
  { id: 17, descripcion: 'Robot aspirador Xiaomi', categoria: 'Electrodomésticos', precio: 299.99 },
  { id: 18, descripcion: 'Cocina de gas Cata', categoria: 'Electrodomésticos', precio: 399.99 },
  { id: 19, descripcion: 'Hervidor Russell Hobbs', categoria: 'Electrodomésticos', precio: 34.99 },
  { id: 20, descripcion: 'Freidora sin aceite Aigostar', categoria: 'Electrodomésticos', precio: 69.99 },
  { id: 21, descripcion: 'Tostadora Moulinex', categoria: 'Electrodomésticos', precio: 29.99 }
  ]
```

Se desea realizar una aplicación para una tienda de venta online que contenga las siguientes rutas:

- **/** para ir al componente inicio, dicho componente contendrá solamente un mensaje de bienvenida
- **/listado** en esta ruta, se deberán visualizar todos los productos en con el nombre, pudiendo seleccionar uno de ellos, e ir a ver un detalle del mismo en la ruta
/producto/:id
- **/producto/:id** para ver el detalle de un producto en particular.
* **\/***  para ir a la ruta de error 404

Realizar la aplicacion en React para la utilización de rutas del lado del cliente


## Resolución

1- Crear componentes:
Crea una carpeta llamada "components" dentro de la carpeta "src" y crea los siguientes archivos de componentes dentro de la carpeta "components":

Listado.js //para listar todos los Listado
Producto.js //Info de un porducto en particular
Navbar.js //barra de navegacion superior
Inicio.js //pagina de inicio
NotFound.js //para errores en la ruta

2.- Implementar el componente Inicio:
En el archivo "Inicio.js", crea un componente simple para mostrar una página de inicio.

```javascript
import React from 'react';

export default function Inicio() {
  return (
    <div>
      <h2>Bienvenido a la Tienda Online</h2>
      <p>Explora nuestra selección de electrodomésticos y línea blanca.</p>
    </div>
  );
}
```

3.-Implementar el componente NotFound:
En el archivo "NotFound.js", crea un componente para manejar las rutas no encontradas.
import React from 'react';

```javascript
import React from 'react';
export default function NotFound() {
  return (
    <div>
      <h2>Error 404: Página no encontrada</h2>
      <p>La página que estás buscando no existe o ha sido eliminada.</p>
    </div>
  );
}
```

4. Implementar el componente Listado:
En el archivo "Listado.js", importa React y los Listado de la tienda online. Luego, crea y exporta un componente que muestre la lista de Listado y enlace a la página de detalles de cada producto. A los fines de simplificar vamos a tener el array de producto definido en el mismo archivo

```javascript
import React from 'react';
import { Link } from 'react-router-dom';

const listado = [/* pegar la lista de objetos de la tienda online aquí */];

export default function Listado() {
  return (
    <div>
      <h2>Listado de productos</h2>
      <ul>
        {listado.map(producto => (
          <li key={producto.id.toString()}>
            <Link to={`/producto/${producto.id}`}>{producto.descripcion}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
```

5. Implementar el componente Producto:
En el archivo "Producto.js", importa React y los productos de la tienda online. Crea y exporta un componente que muestre los detalles de un producto específico utilizando el ID del producto proporcionado en la URL.

```javascript
import React from 'react';
import { useParams } from 'react-router-dom';

const productos = [/* pegar la lista de objetos de la tienda online aquí */];

export default function Producto() {
  const { id } = useParams();
  const producto = productos.find(p => p.id === parseInt(id));

  if (!producto) {
    return <p>Producto no encontrado</p>;
  }

  return (
    <div>
      <h2>{producto.descripcion}</h2>
      <p>Categoría: {producto.categoria}</p>
      <p>Precio: ${producto.precio.toFixed(2).toString()}</p>
    </div>
  );
}
```

6.- Implementar el componente Navbar:
En el archivo "Navbar.js", importa React y crea un componente de navegación simple que enlace a la página de inicio.

```javascript
import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav>
      <Link to="/">Inicio</Link> | <Link to="/listado">Listado</Link>
    </nav>
  );
}
```

7.- Configurar las rutas en "src/App.js":

```javascript
import React from 'react';
import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Inicio from './components/Inicio';
import Listado from './components/Listado';
import Producto from './components/Producto';
import NotFound from './components/NotFound';

function App() {
  return (
    <Router>
      <div>
        <Navbar />
        <Routes>
          <Route path="/" element={<Inicio />} index />
          <Route path="/listado" element={<Listado />} />
          <Route path="/producto/:id" element={<Producto />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
```
