# Desarrollo de Software - Semana 11

## Contenido de la semana

- Profundizando concetpos de React
  - Ruteo y navegación
  - Comunicación entre componentes

## Lista de materiales

- [Apunte 21](./apunte-21/Apunte21.md)
- [Apunte 22](./apunte-22/Apunte22.md)

## Clonar el presente repositorio

``` bash
cd dds_work_dir
git clone https://labsys.frc.utn.edu.ar/gitlab/desarrollo-de-software1/materiales/semana-11.git
```

## Lista de Ejemplos

- [Ejercitación guiada](./ejercitacion/ejercitacionguiada.md)

## Autores

Darío Voefrey - Cátedra de Desarrollo de Software

## License

Este trabajo está licenciado bajo una Licencia Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional. Para ver una copia de esta licencia, visita [https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es](!https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es).
